package AdvanceJava.Task1.DesignPatterns.singleton;

public class EagerSingleton {

    private static final EagerSingleton instance = new EagerSingleton();

    private String name;
    private int id;

    private EagerSingleton()
    {

    }

    public static EagerSingleton getInstance()
    {
        return instance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



}
