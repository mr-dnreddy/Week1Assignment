package AdvanceJava.Task1.DesignPatterns.singleton;


public class LazySingleton {

    private static LazySingleton instance;

    private int id;
    private String name;

    private LazySingleton()
    {

    }
    public static synchronized LazySingleton getInstance()
    {
        if(instance == null)
        {
            instance = new LazySingleton();
        }
        return instance;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }



}
