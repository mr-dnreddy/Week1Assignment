package AdvanceJava.Task1.DesignPatterns.singleton;

public class DoubleChecked {

    private static volatile DoubleChecked instance;

    private int id;
    private String name;



    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;

    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    private DoubleChecked()
    {

    }
    public static DoubleChecked getInstance()
    {
        if(instance == null)
        {
            synchronized (DoubleChecked.class) {

                if( instance == null)
                {
                    instance = new DoubleChecked();
                }

            }
        }
        return instance;
    }

}
