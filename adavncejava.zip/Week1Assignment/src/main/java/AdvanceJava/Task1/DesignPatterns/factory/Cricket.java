package AdvanceJava.Task1.DesignPatterns.factory;

public class Cricket implements Sport {

	@Override
	public String play() {
		
		return " Playying Cricket ";
	}
	
	

}
