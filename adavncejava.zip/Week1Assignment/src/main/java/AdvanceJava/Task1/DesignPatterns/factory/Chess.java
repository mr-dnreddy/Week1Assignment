package AdvanceJava.Task1.DesignPatterns.factory;

public class Chess implements Sport {

	@Override
	public String play() {
		
		return " Playying Chess";
	}

}
