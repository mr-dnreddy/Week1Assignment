package AdvanceJava.Task1.DesignPatterns.singleton;

public class LazySingletonImplementation {

    public static void main(String[] args)
    {
        LazySingleton lazysingleton1 = LazySingleton.getInstance();

        LazySingleton lazysingleton2 = LazySingleton.getInstance();


        if(lazysingleton1 == lazysingleton2)
            System.out.println("values are same and singleton is working fine");
        else
            System.out.println("values are different and singleton has failed");

    }

}
