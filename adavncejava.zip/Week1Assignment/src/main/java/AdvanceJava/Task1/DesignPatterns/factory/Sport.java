package AdvanceJava.Task1.DesignPatterns.factory;

public interface Sport {
	
	String play();

}
