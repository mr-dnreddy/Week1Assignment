package AdvanceJava.Task1.DesignPatterns.factory;

public class Tennis implements Sport {

	@Override
	public String play() {
		
		return " Playying Tennis";
	}

}
