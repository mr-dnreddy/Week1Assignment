package AdvanceJava.Task1.DesignPatterns.strategy;

public interface PaymentStrategy {

    void pay(int amount);
}
