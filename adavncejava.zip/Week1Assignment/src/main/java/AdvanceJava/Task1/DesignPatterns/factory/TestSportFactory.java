package AdvanceJava.Task1.DesignPatterns.factory;

public class TestSportFactory {
	
	public static void main(String[] args)
	{
		Sport crckt = SportFactory.createSport("cricket");
		Sport tns = SportFactory.createSport("tennis");
		Sport chess = SportFactory.createSport("chess");
		
		displaySportDetails(crckt);
		displaySportDetails(tns);
		displaySportDetails(chess);
		
		
		
	}
	
	private static void displaySportDetails(Sport sport)
	{
		System.out.println(sport.play());
	}

}
