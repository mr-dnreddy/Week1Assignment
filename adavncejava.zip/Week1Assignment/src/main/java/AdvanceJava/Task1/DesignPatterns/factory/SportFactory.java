package AdvanceJava.Task1.DesignPatterns.factory;

public class SportFactory {
	
	public static Sport createSport(String sportType)
	{
		switch(sportType.toLowerCase())
		{
		case "cricket" :
			return new Cricket();
		case "tennis" : 
			return new Tennis();
		case "chess" :
			return new Chess();
		default :
			throw new IllegalArgumentException("Unknown sport type : " + sportType);
		}
		
	}

}
