package AdvanceJava.Task1.DesignPatterns.singleton;

public class EagerSingletonImplementation {

    public static void main(String[] args)
    {
        EagerSingleton eagersingleton1 = EagerSingleton.getInstance();
        EagerSingleton eagersingleton2 = EagerSingleton.getInstance();

        eagersingleton1.setId(1);
        eagersingleton1.setName("Nasar");

        eagersingleton2.setId(2);
        eagersingleton2.setName("Reddy");

        System.out.println("Id = " + eagersingleton1.getId());
        System.out.println("Name = " + eagersingleton1.getName());

        System.out.println("Id = " + eagersingleton2.getId());
        System.out.println("Name = " + eagersingleton2.getName());

        if(eagersingleton1 == eagersingleton2)
            System.out.println("values are same and singleton is working fine");
        else
            System.out.println("values are different and singleton has failed");
    }


}
