package AdvanceJava.Task1.DesignPatterns.singleton;

public class DoubleCheckedImplementation {

    public static void main(String[] args)
    {
        DoubleChecked doublechecked1 = DoubleChecked.getInstance();
        DoubleChecked doublechecked2 = DoubleChecked.getInstance();

        doublechecked1.setId(1);
        doublechecked1.setName("Nasar");

        doublechecked2.setId(2);
        doublechecked2.setName("Reddy");

        System.out.println("ID  " + doublechecked1.getId());
        System.out.println("Name " + doublechecked1.getName());

        System.out.println("ID  " + doublechecked2.getId());
        System.out.println("Name " + doublechecked2.getName());

        if(doublechecked1 == doublechecked2 )
            System.out.println("objects are same and singleton is working fine");
        else
            System.out.println("objects are different and singleton is failed");
    }

}
