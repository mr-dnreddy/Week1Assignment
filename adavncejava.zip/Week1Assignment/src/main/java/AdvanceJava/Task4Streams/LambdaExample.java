package AdvanceJava.Task4Streams;

@FunctionalInterface
interface MathOperation {
    int operate(int a, int b);
}

public class LambdaExample {

    public static void main(String[] args) {
        // Using lambda expression to implement MathOperation interface
        MathOperation addition = (a, b) -> a + b;
        MathOperation subtraction = (a, b) -> a - b;

        System.out.println("Addition result: " + operate(10, 5, addition));
        System.out.println("Subtraction result: " + operate(10, 5, subtraction));
    }

    private static int operate(int a, int b, MathOperation operation) {
        return operation.operate(a, b);
    }
}

