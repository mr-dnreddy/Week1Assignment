package AdvanceJava.Task4Streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamExample {

    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        // Filter even numbers
        List<Integer> evenNumbers = numbers.stream()
                .filter(num -> num % 2 == 0)
                .collect(Collectors.toList());

        System.out.println("Filtering Even numbers using Streams: " + evenNumbers);

        // Map each number to its square
        List<Integer> squares = numbers.stream()
                .map(num -> num * num)
                .collect(Collectors.toList());

        System.out.println("Printing Squares of numbers using Streams: " + squares);

        // Reduce to find the sum of all numbers
        int sum = numbers.stream()
                .reduce(0, Integer::sum);

        System.out.println("Sum of numbers using Streams: " + sum);
    }
}
