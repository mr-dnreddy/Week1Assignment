package AdvanceJava.Task2.Collections;


import java.util.*;
import java.util.stream.Collectors;

public class CollectionsPractice {
    public static void main(String[] args) {
        // Example with ArrayList
        List<String> names = new ArrayList<>(Arrays.asList("John", "Alice", "Bob", "Charlie", "David"));

        // Sorting
        List<String> sortedNames = names.stream()
                .sorted()
                .collect(Collectors.toList());
        System.out.println("Sorted Names: " + sortedNames);
        System.out.println("---------------------------------");
        // Filtering
        List<String> filteredNames = names.stream()
                .filter(name -> name.startsWith("A"))
                .collect(Collectors.toList());
        System.out.println("Filtered Names (start with A): " + filteredNames);
        System.out.println("---------------------------------");

        // Mapping
        List<String> upperCaseNames = names.stream()
                .map(String::toUpperCase)
                .collect(Collectors.toList());
        System.out.println("Upper Case Names: " + upperCaseNames);
        System.out.println("---------------------------------");

        // Iteration
        System.out.println("Iterating over names:");
        names.forEach(System.out::println);
        System.out.println("---------------------------------");

        // Example with HashMap
        Map<String, Integer> ageMap = new HashMap<>();
        ageMap.put("John", 25);
        ageMap.put("Alice", 30);
        ageMap.put("Bob", 20);
        ageMap.put("Charlie", 35);
        ageMap.put("David", 28);

        // Sorting by keys
        Map<String, Integer> sortedByKey = ageMap.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));
        System.out.println("Sorted by Key: " + sortedByKey);
        System.out.println("---------------------------------");

        // Sorting by values
        Map<String, Integer> sortedByValue = ageMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));
        System.out.println("Sorted by Value: " + sortedByValue);
        System.out.println("---------------------------------");

        // Filtering
        Map<String, Integer> filteredMap = ageMap.entrySet().stream()
                .filter(entry -> entry.getValue() > 25)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        System.out.println("Filtered Map (age > 25): " + filteredMap);
        System.out.println("---------------------------------");

        // Iteration
        System.out.println("Iterating over ageMap:");
        ageMap.forEach((name, age) -> System.out.println(name + ": " + age));
        System.out.println("---------------------------------");
    }
}
